#ifndef PRODUCTS_H
#define PRODUCTS_H

#include <stdio.h>
#include <stdlib.h>
#include "odbc.h"

int PrintStock();
int PrintFind();
#endif