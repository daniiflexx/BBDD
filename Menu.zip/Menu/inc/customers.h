#ifndef CUSTOMERS_H
#define CUSTOMERS_H

#include <stdio.h>
#include <stdlib.h>
#include "odbc.h"

int Find();
int ListProducts();
int Balance();

#endif
